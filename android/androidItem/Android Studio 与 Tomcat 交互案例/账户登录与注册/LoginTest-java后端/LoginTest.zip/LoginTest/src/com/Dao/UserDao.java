package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Utils.JDBCUtils;
import com.beans.User;

public class UserDao {

	private Connection conn;

	public UserDao() {
		try {
			conn = JDBCUtils.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean loginCheck(User user) {

		boolean res = false;

		String sql = "select * from user_table where user=? and pwd=?";

		try {
			PreparedStatement pst = conn.prepareStatement(sql);

			pst.setString(1, user.getAdmin());

			pst.setString(2, user.getPassword());
			
			ResultSet rs = pst.executeQuery();

			if (rs.first())
				res = true;
			else
				res = false;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return res;

	}

	public boolean registUser(User user) {
		

		boolean res = false;
		
		if(loginCheck(user)) return false;
		
		String sql = "insert into user_table(user,pwd) values(?,?)";

		try {
			PreparedStatement pst = conn.prepareStatement(sql);

			pst.setString(1, user.getAdmin());

			pst.setString(2, user.getPassword());

			int n = pst.executeUpdate();

			if (n > 0)
				res = true;
			else
				res = false;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return res;
	}
}
