package com.Test;

import com.Dao.UserDao;
import com.beans.User;

public class test {

	public static void main(String[] args) {
		
		User user = new User();
		
		user.setAdmin("4434334");
		
		user.setPassword("14");
		
		UserDao userDao = new UserDao();
		
		System.out.println(userDao.registUser(user));
	}
	
	
}
