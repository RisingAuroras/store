package com.beans;

public class User {
	private String admin;
	private String password;
	
	public User() {
	}
	
	public User(String admin, String password) {
		super();
		this.admin = admin;
		this.password = password;
	}

	/** 
	* @return admin 
	*/
	public String getAdmin() {
		return admin;
	}

	/** 
	* @param admin 要设置的 admin 
	*/
	public void setAdmin(String admin) {
		this.admin = admin;
	}

	/** 
	* @return password 
	*/
	public String getPassword() {
		return password;
	}

	/** 
	* @param password 要设置的 password 
	*/
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
