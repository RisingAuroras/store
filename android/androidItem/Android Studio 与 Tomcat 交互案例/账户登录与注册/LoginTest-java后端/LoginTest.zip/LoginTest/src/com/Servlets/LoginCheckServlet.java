package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.UserDao;
import com.beans.User;

/**
 * Servlet implementation class LoginCheckServlet
 */
@WebServlet("/loginCheckServlet")
public class LoginCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserDao userDao = new UserDao();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginCheckServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String flag = request.getParameter("flag");

		switch (flag) {

		case "login":
			login(request, response);
			break;
		case "regist":
			regist(request, response);
			break;
		}

	}

	private boolean check(String str) {
		if (str != null && !"".equals(str.trim()))
			return true;
		return false;
	}

	protected void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String admin = request.getParameter("admin");

		String password = request.getParameter("password");

		PrintWriter out = response.getWriter();

		boolean res = false;

		if (check(admin) && check(password)) {

			res = userDao.loginCheck(new User(admin, password));
		}

		if (res == true) {

			out.print("true");
			out.flush();
			out.close();
		}

		else {
			out.print("false");
			out.flush();
			out.close();
		}

	}

	protected void regist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String admin = request.getParameter("admin");

		String password = request.getParameter("password");

		PrintWriter out = response.getWriter();

		boolean res = false;

		if (check(admin) && check(password)) {

			res = userDao.registUser(new User(admin, password));
		}

		if (res == true) {

			out.print("true");
			out.flush();
			out.close();
		}

		else {
			out.print("false");
			out.flush();
			out.close();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
